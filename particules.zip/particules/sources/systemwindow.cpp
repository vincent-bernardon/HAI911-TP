#include "systemwindow.h"
#include <QMatrix4x4>
#include <QOpenGLShader>
#include <QScreen>
#include <QtMath>
#include <QDebug>
#include <QMouseEvent>
#include <QOpenGLFunctions>
#include <QOpenGLFunctions_4_3_Core>
#include <QDateTime>

void ParticleSystemWindow::initialize() {
    m_context = new QOpenGLContext(this);
    m_context->create();

    //Switch to OpenGL context
    m_context->makeCurrent(this);
    gl43 = QOpenGLContext::currentContext()->versionFunctions<QOpenGLFunctions_4_3_Core>();
    if (!gl43) {
        qFatal("Impossible to initialize OpenGLFunction 4.3 Core.");
    }
    gl43->initializeOpenGLFunctions();
    srand(static_cast<unsigned int>(QDateTime::currentMSecsSinceEpoch() & 0xFFFFFFFF));

    particles.resize(numParticles);
    for (auto& p : particles) p.init();

    vbo.create();
    /*vbo.bind();
    vbo.allocate(numParticles * 3 * sizeof(GLfloat));
*/
    m_camera.setAspectRatio(width() / float(height()));

    program = new QOpenGLShaderProgram(this);
    program->addShaderFromSourceFile(QOpenGLShader::Vertex, "../shaders/particle.vert");
    program->addShaderFromSourceFile(QOpenGLShader::Geometry, "../shaders/particle.geom");
    program->addShaderFromSourceFile(QOpenGLShader::Fragment, "../shaders/particle.frag");
    program->link();
    program->bind();

    matrixUniform = program->uniformLocation("mvp");

    glEnable(GL_PROGRAM_POINT_SIZE);
    glPointSize(5.0f);
}

void ParticleSystemWindow::render() {
    const qreal retinaScale = devicePixelRatio();
    glViewport(0, 0, width() * retinaScale, height() * retinaScale);
    glEnable(GL_DEPTH_TEST);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(1.f, 1.0f, 1.0f, 1.0f);

    particlePositions.clear();
    particlePositions.reserve(numParticles * 3);
    for (auto& p : particles) {
        p.animate();
        particlePositions.push_back(p.pos.x());
        particlePositions.push_back(p.pos.y());
        particlePositions.push_back(p.pos.z());
    }

    vbo.bind();
    vbo.allocate(particlePositions.data(), particlePositions.size() * sizeof(GLfloat) * 3);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    glEnableVertexAttribArray(0);

    program->bind();
    
    QMatrix4x4 mvp = m_camera.projectionMatrix() * m_camera.viewMatrix();
    program->setUniformValue(matrixUniform, mvp);

    glDrawArrays(GL_POINTS, 0, numParticles);

    program->release();
}


